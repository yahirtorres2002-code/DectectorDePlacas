# PlacaDeSinaloa > DataSet_PlacasDeSinaloa_Version1
https://universe.roboflow.com/placassinaloa/placadesinaloa-lcbjy

Provided by a Roboflow user
License: CC BY 4.0

